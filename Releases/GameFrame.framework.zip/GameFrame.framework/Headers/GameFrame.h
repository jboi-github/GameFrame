//
//  GameFrame.h
//  GameFrame
//
//  Created by Juergen Boiselle on 29.10.19.
//  Copyright © 2019 Juergen Boiselle. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GameFrame.
FOUNDATION_EXPORT double GameFrameVersionNumber;

//! Project version string for GameFrame.
FOUNDATION_EXPORT const unsigned char GameFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GameFrame/PublicHeader.h>


